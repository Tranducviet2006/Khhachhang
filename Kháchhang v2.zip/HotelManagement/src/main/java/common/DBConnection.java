package common;

import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.Properties;

/** Đọc cấu hình kết nối ngoài source. */
public final class DBConnection implements ConnectionFactory {
    private final Properties properties = new Properties();
    public DBConnection(Path path) throws IOException {
        try (var reader = Files.newBufferedReader(path)) { properties.load(reader); }
        if (cauHinh("url").isBlank()) throw new IOException("Cấu hình thiếu db.url JDBC.");
    }
    private String cauHinh(String ten) {
        return properties.getProperty("db." + ten, properties.getProperty(ten, ""));
    }
    @Override public Connection open() throws SQLException {
        String password = System.getenv("HOTEL_DB_PASSWORD");
        if (password == null) password = cauHinh("password");
        return DriverManager.getConnection(cauHinh("url"), cauHinh("user"), password);
    }
}
