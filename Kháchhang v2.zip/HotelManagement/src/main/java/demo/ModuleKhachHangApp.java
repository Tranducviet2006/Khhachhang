package demo;

import common.DBConnection;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.Properties;
import javax.swing.*;
import module_khachhang.controller.KhachHangController;
import module_khachhang.dao.*;
import module_khachhang.model.*;
import module_khachhang.service.KhachHangService;
import module_khachhang.view.KhachHangPanel;

/** JFrame chạy thử; MainFrame của nhóm sẽ nhúng KhachHangPanel trực tiếp. */
public final class ModuleKhachHangApp {
    private ModuleKhachHangApp() {
    }

    public static void main(String[] args) {
        final KhachHangService service;
        final String mode;
        try {
            Path path = Path.of("config/db.properties");
            Properties config = new Properties();
            if (Files.exists(path)) try (var reader = Files.newBufferedReader(path)) { config.load(reader); }
            String configured = config.getProperty("mode", "demo");
            if (configured.equals("sqlserver")) {
                service = new KhachHangService(new SqlServerKhachHangDAO(new DBConnection(path)));
                mode = "SQL Server • Dữ liệu được lưu trong database";
            } else if (configured.equals("demo")) {
                service = new KhachHangService(new MemoryKhachHangDAO());
                taoDuLieuMau(service);
                mode = "DEMO • Dữ liệu chỉ giữ trong lần chạy này; đóng ứng dụng sẽ mất thay đổi";
            } else throw new IllegalArgumentException("mode phải là demo hoặc sqlserver.");
        } catch (Exception e) {
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, e.getMessage(),
                    "Không khởi động được", JOptionPane.ERROR_MESSAGE));
            return;
        }
        SwingUtilities.invokeLater(() -> {
            try {
                for (var info : UIManager.getInstalledLookAndFeels()) if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName()); break;
                }
            } catch (Exception ignored) { /* Giữ giao diện mặc định khi Nimbus không khả dụng. */ }
            JFrame frame = new JFrame("Hotel Management — Khách hàng");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new KhachHangPanel(new KhachHangController(service), mode));
            frame.setSize(1180, 720);
            frame.setMinimumSize(new java.awt.Dimension(900, 580));
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    private static void taoDuLieuMau(KhachHangService service) {
        service.themKhachHang(new DuLieuKhachHang("Nguyễn Minh Anh", LoaiGiayTo.CCCD,
                "012345678901", "VN", "0901234567", "anh@example.com", LocalDate.of(2000, 5, 20),
                GioiTinh.NU, "VN", "Hà Nội"));
        service.themKhachHang(new DuLieuKhachHang("Trần Hoàng Nam", null, null, null,
                "0912345678", null, LocalDate.of(1998, 10, 3), GioiTinh.NAM, "VN", "TP. Hồ Chí Minh"));
        service.themKhachHang(new DuLieuKhachHang("Alex Morgan", LoaiGiayTo.PASSPORT,
                "DEMO12345", "US", "+12025550123", "alex@example.com", null, GioiTinh.KHONG_CUNG_CAP, "US", null));
        var old = service.themKhachHang(new DuLieuKhachHang("Lê Thu Hà", null, null, null,
                null, null, null, GioiTinh.NU, "VN", null));
        service.voHieuHoa(old.maKhachHang());
    }
}
