package module_khachhang;

import common.DBConnection;
import java.nio.file.*;
import java.sql.*;
import java.util.Properties;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class DBConnectionTest {
    @TempDir Path directory;

    @Test void supportsSharedKeysAndPrioritisesThem() throws Exception {
        check("db.url=jdbc:hotel-test:shared\ndb.user=shared\ndb.password=test\n"
                + "url=jdbc:hotel-test:old\nuser=old\npassword=old\n", "jdbc:hotel-test:shared", "shared", "test");
    }

    @Test void acceptsExistingLegacyConfiguration() throws Exception {
        check("url=jdbc:hotel-test:old\nuser=old\npassword=test\n", "jdbc:hotel-test:old", "old", "test");
    }

    private void check(String config, String expectedUrl, String user, String password) throws Exception {
        Path path = directory.resolve("db.properties");
        Files.writeString(path, config);
        TestDriver driver = new TestDriver();
        DriverManager.registerDriver(driver);
        try {
            // Driver thử chỉ ghi lại tham số, không kết nối mạng.
            new DBConnection(path).open();
            assertEquals(expectedUrl, driver.url);
            assertEquals(user, driver.info.getProperty("user"));
            String env = System.getenv("HOTEL_DB_PASSWORD");
            assertEquals(env == null ? password : env, driver.info.getProperty("password"));
        } finally { DriverManager.deregisterDriver(driver); }
    }

    private static final class TestDriver implements Driver {
        String url;
        Properties info;
        public Connection connect(String url, Properties info) {
            if (!acceptsURL(url)) return null;
            this.url = url; this.info = info;
            return (Connection) java.lang.reflect.Proxy.newProxyInstance(getClass().getClassLoader(),
                    new Class<?>[]{Connection.class}, (proxy, method, args) -> null);
        }
        public boolean acceptsURL(String url) { return url.startsWith("jdbc:hotel-test:"); }
        public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) { return new DriverPropertyInfo[0]; }
        public int getMajorVersion() { return 1; }
        public int getMinorVersion() { return 0; }
        public boolean jdbcCompliant() { return false; }
        public Logger getParentLogger() { return Logger.getGlobal(); }
    }
}
