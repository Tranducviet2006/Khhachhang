package module_khachhang;

import module_khachhang.dao.MemoryKhachHangDAO;
import module_khachhang.model.*;
import module_khachhang.service.KhachHangService;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TuongThichModuleTest {
    private final KhachHangService service = new KhachHangService(new MemoryKhachHangDAO());

    @Test void supportsRoomModuleAccessors() {
        var p = service.themKhachHang(new DuLieuKhachHang("A", LoaiGiayTo.CCCD, "012345678901", "VN",
                "0912345678", null, null, null, "VN", null));
        assertEquals(p.soDienThoai(), p.sdt());
        assertEquals("012345678901", p.cccd());
    }

    @Test void doesNotTreatPassportAsCccd() {
        var p = service.themKhachHang(new DuLieuKhachHang("A", LoaiGiayTo.PASSPORT, "AB123", "US",
                null, null, null, null, "US", null));
        assertNull(p.cccd());
        assertEquals("AB123", p.soGiayTo());
    }

    @Test void roomModuleListExcludesInactiveGuests() {
        var p = service.themKhachHang(new DuLieuKhachHang("A", null, null, null,
                null, null, null, null, null, null));
        assertEquals(1, service.getKhachHangs().size());
        service.voHieuHoa(p.maKhachHang());
        assertTrue(service.getKhachHangs().isEmpty());
    }
}
