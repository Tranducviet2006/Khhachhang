package module_khachhang;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import module_khachhang.dao.*;
import module_khachhang.model.*;
import module_khachhang.service.*;
import module_khachhang.controller.*;
import module_khachhang.view.*;
public class SwingWorkflowSmoke {
 static JFrame frame; static KhachHangPanel panel; static KhachHangService service;
 static <T> T edt(Callable<T> call) throws Exception {
  AtomicReference<T> result = new AtomicReference<>(); AtomicReference<Throwable> failure = new AtomicReference<>();
  SwingUtilities.invokeAndWait(() -> { try {result.set(call.call());} catch(Throwable t){failure.set(t);} });
  if(failure.get()!=null) throw new RuntimeException(failure.get()); return result.get();
 }
 static Component find(Container root, Predicate<Component> match) {
  for(Component c:root.getComponents()) { if(match.test(c))return c; if(c instanceof Container ct){var r=find(ct,match); if(r!=null)return r;} } return null;
 }
 static JButton button(Container root,String text){return (JButton)find(root,c->c instanceof JButton b && text.equals(b.getText()));}
 static JTable table(){return (JTable)find(panel,c->c instanceof JTable);}
 static JDialog dialog(Class<?> type){for(Window w:Window.getWindows())if(w instanceof JDialog d && d.isShowing() && type.isInstance(d))return d; return null;}
 static void waitFor(Callable<Boolean> check) throws Exception {long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(8);while(System.nanoTime()<end){if(edt(check))return;Thread.sleep(40);}throw new AssertionError("UI timeout");}
 static JTextField field(Container root,String label){var l=(JLabel)find(root,c->c instanceof JLabel x && label.equals(x.getText()));return (JTextField)l.getLabelFor();}
 static void modalClick(String name){SwingUtilities.invokeLater(()->button(panel,name).doClick());}
 static void confirm()throws Exception {waitFor(()->dialog(JDialog.class)!=null); edt(()->{for(Window w:Window.getWindows())if(w instanceof JDialog d && d.isShowing()){var option=(JOptionPane)find(d,c->c instanceof JOptionPane);if(option!=null)option.setValue(JOptionPane.YES_OPTION);}return null;});}
 public static void main(String[]args)throws Exception {
  int exitStatus = 0;
  try {
   service=new KhachHangService(new MemoryKhachHangDAO());
   for(String name:new String[]{"Nguyễn Minh Anh","Trần Hoàng Nam","Alex Morgan","Lê Thu Hà"})service.themKhachHang(new DuLieuKhachHang(name,null,null,null,null,null,null,GioiTinh.KHONG_CUNG_CAP,"VN",null));
   edt(()->{for(var l:UIManager.getInstalledLookAndFeels())if(l.getName().equals("Nimbus"))UIManager.setLookAndFeel(l.getClassName()); frame=new JFrame("Kiểm tra module Khách hàng");panel=new KhachHangPanel(new KhachHangController(service),"DEMO • Dữ liệu chỉ giữ trong lần chạy này; đóng ứng dụng sẽ mất thay đổi");frame.setContentPane(panel);frame.setSize(1180,720);frame.setLocationRelativeTo(null);frame.setVisible(true);return null;});
   waitFor(()->table().getRowCount()==4 && button(panel,"Thêm khách").isEnabled());
   modalClick("Thêm khách");waitFor(()->dialog(KhachHangFormDialog.class)!=null);
   edt(()->{var d=dialog(KhachHangFormDialog.class);field(d,"Họ tên *").setText("Khách kiểm thử");field(d,"Ngày sinh (dd/MM/yyyy)").setText("25/12/2000");button(d,"Lưu hồ sơ").doClick();return null;});
   waitFor(()->table().getRowCount()==5 && dialog(KhachHangFormDialog.class)==null);System.out.println("ADD_OK");
   edt(()->{table().setRowSelectionInterval(4,4);return null;});modalClick("Sửa");waitFor(()->dialog(KhachHangFormDialog.class)!=null);
   edt(()->{var d=dialog(KhachHangFormDialog.class);field(d,"Họ tên *").setText("Khách đã sửa");button(d,"Lưu hồ sơ").doClick();return null;});
   waitFor(()->dialog(KhachHangFormDialog.class)==null && "Khách đã sửa".equals(table().getValueAt(4,1)));System.out.println("EDIT_OK");
   modalClick("Xem chi tiết");waitFor(()->dialog(ChiTietKhachHangDialog.class)!=null);
   edt(()->{var d=dialog(ChiTietKhachHangDialog.class);var text=(JTextArea)find(d,c->c instanceof JTextArea);if(!text.getText().contains("Khách đã sửa"))throw new AssertionError();d.dispose();return null;});System.out.println("DETAIL_OK");
   modalClick("Vô hiệu hóa");confirm();waitFor(()->"Kích hoạt lại".equals(button(panel,"Kích hoạt lại")==null?"":button(panel,"Kích hoạt lại").getText()) && button(panel,"Kích hoạt lại").isEnabled());
   if(service.getKhachHangHoatDong().size()!=4)throw new AssertionError();System.out.println("DEACTIVATE_OK");
   modalClick("Kích hoạt lại");confirm();waitFor(()->button(panel,"Vô hiệu hóa")!=null && button(panel,"Vô hiệu hóa").isEnabled());
   if(service.getKhachHangHoatDong().size()!=5)throw new AssertionError();System.out.println("REACTIVATE_OK");
   edt(()->{field(panel,"Tìm kiếm").setText("Khách đã sửa");return null;});waitFor(()->table().getRowCount()==1 && button(panel,"Bỏ lọc").isEnabled());
   edt(()->{button(panel,"Bỏ lọc").doClick();return null;});waitFor(()->table().getRowCount()==5 && button(panel,"Thêm khách").isEnabled());System.out.println("SEARCH_RESET_OK");
   edt(()->{var image=new BufferedImage(panel.getWidth(),panel.getHeight(),BufferedImage.TYPE_INT_RGB);var g=image.createGraphics();panel.printAll(g);g.dispose();ImageIO.write(image,"png",Path.of(args[0]).toFile());return null;});
   System.out.println("UI_OK");
  }catch(Throwable failure) { failure.printStackTrace(); exitStatus = 1; }
  finally {edt(()->{for(Window w:Window.getWindows())w.dispose();return null;});System.exit(exitStatus);}
 }
}
