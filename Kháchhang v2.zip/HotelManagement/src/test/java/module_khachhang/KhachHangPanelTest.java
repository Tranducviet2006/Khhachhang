package module_khachhang;

import java.awt.*;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import javax.swing.*;
import module_khachhang.controller.KhachHangController;
import module_khachhang.dao.*;
import module_khachhang.model.*;
import module_khachhang.service.KhachHangService;
import module_khachhang.view.KhachHangPanel;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class KhachHangPanelTest {
    private static <T extends Component> T find(Container root, Class<T> type) {
        for (Component c : root.getComponents()) {
            if (type.isInstance(c)) return type.cast(c);
            if (c instanceof Container child) { T found = find(child, type); if (found != null) return found; }
        }
        return null;
    }
    private static JButton button(Container root, String text) {
        for (Component c : root.getComponents()) {
            if (c instanceof JButton b && text.equals(b.getText())) return b;
            if (c instanceof Container child) { var found = button(child, text); if (found != null) return found; }
        }
        return null;
    }
    @Test void loadsInBackgroundAndEnablesActionsOnlyWithSelection() throws Exception {
        var memory = new MemoryKhachHangDAO();
        var service = new KhachHangService(memory);
        service.themKhachHang(new DuLieuKhachHang("Nguyễn A", null, null, null, null, null, null, GioiTinh.NAM, "VN", null));
        CountDownLatch read = new CountDownLatch(1);
        AtomicReference<Boolean> calledOnEdt = new AtomicReference<>();
        KhachHangDAO checked = new KhachHangDAO() {
            public List<KhachHang> danhSach() { calledOnEdt.set(SwingUtilities.isEventDispatchThread()); read.countDown(); return memory.danhSach(); }
            public KhachHang get(String ma) { return memory.get(ma); }
            public KhachHang them(DuLieuKhachHang d, java.time.LocalDateTime time) { return memory.them(d, time); }
            public void sua(String ma, DuLieuKhachHang d) { memory.sua(ma, d); }
            public void doiTrangThai(String ma, TrangThaiKhachHang s) { memory.doiTrangThai(ma, s); }
        };
        AtomicReference<KhachHangPanel> holder = new AtomicReference<>();
        CountDownLatch loaded = new CountDownLatch(1);
        SwingUtilities.invokeAndWait(() -> {
            var panel = new KhachHangPanel(new KhachHangController(new KhachHangService(checked)), "Demo");
            holder.set(panel);
            assertFalse(button(panel, "Sửa").isEnabled());
            var table = find(panel, JTable.class);
            table.getModel().addTableModelListener(e -> { if (table.getRowCount() == 1) loaded.countDown(); });
        });
        assertTrue(read.await(5, TimeUnit.SECONDS));
        assertTrue(loaded.await(5, TimeUnit.SECONDS));
        assertEquals(Boolean.FALSE, calledOnEdt.get());
        SwingUtilities.invokeAndWait(() -> {
            var panel = holder.get(); var table = find(panel, JTable.class);
            assertEquals("Nguyễn A", table.getValueAt(0, 1));
            assertFalse(table.isCellEditable(0, 1));
            table.setRowSelectionInterval(0, 0);
            assertTrue(button(panel, "Sửa").isEnabled());
            assertTrue(button(panel, "Xem chi tiết").isEnabled());
            table.getRowSorter().toggleSortOrder(1);
            panel.hienThi(service.timKhachHang(new BoLocKhachHang(null, null, null, null)));
            assertEquals("Nguyễn A", table.getValueAt(table.getSelectedRow(), 1));
            panel.hienThi(List.of());
            assertFalse(button(panel, "Sửa").isEnabled());
            assertEquals(0, table.getRowCount());
        });
    }
}
