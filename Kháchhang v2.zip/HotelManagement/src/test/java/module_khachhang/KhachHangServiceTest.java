package module_khachhang;

import java.time.*;
import java.util.concurrent.*;
import module_khachhang.dao.MemoryKhachHangDAO;
import module_khachhang.model.*;
import module_khachhang.service.KhachHangService;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class KhachHangServiceTest {
    private final KhachHangService service = new KhachHangService(new MemoryKhachHangDAO());
    private DuLieuKhachHang data(String name, LoaiGiayTo type, String number, String country) {
        return new DuLieuKhachHang(name, type, number, country, "0912345678",
                "khach@example.com", LocalDate.of(2000, 1, 1), GioiTinh.NAM, "VN", "Hà Nội");
    }
    @Test void createsNormalisedProfileWithoutDocuments() {
        var p = service.themKhachHang(data("  Nguyễn Văn A  ", null, "", ""));
        assertEquals("Nguyễn Văn A", p.hoTen());
        assertNull(p.soGiayTo());
        assertEquals(TrangThaiKhachHang.HOAT_DONG, p.trangThai());
        assertTrue(p.maKhachHang().startsWith("KH"));
    }
    @Test void rejectsDuplicateDocumentEvenWhenInactive() {
        var d = data("A", LoaiGiayTo.CCCD, "012345678901", "VN");
        var p = service.themKhachHang(d);
        service.voHieuHoa(p.maKhachHang());
        assertThrows(IllegalArgumentException.class, () -> service.themKhachHang(d));
    }
    @Test void passportUniquenessIncludesIssuingCountry() {
        service.themKhachHang(data("A", LoaiGiayTo.PASSPORT, "ab123", "US"));
        service.themKhachHang(data("B", LoaiGiayTo.PASSPORT, "AB123", "GB"));
        assertThrows(IllegalArgumentException.class, () ->
                service.themKhachHang(data("C", LoaiGiayTo.PASSPORT, "AB123", "US")));
    }
    @Test void updatePreservesIdentityCreatedTimeAndStatus() {
        var p = service.themKhachHang(data("A", null, null, null));
        service.voHieuHoa(p.maKhachHang());
        service.suaKhachHang(p.maKhachHang(), data("B", null, null, null));
        var updated = service.getKhachHang(p.maKhachHang());
        assertEquals(p.ngayTao(), updated.ngayTao());
        assertEquals("B", updated.hoTen());
        assertEquals(TrangThaiKhachHang.NGUNG_HOAT_DONG, updated.trangThai());
        assertTrue(service.getKhachHangHoatDong().isEmpty());
        service.kichHoatLai(p.maKhachHang());
        assertEquals(1, service.getKhachHangHoatDong().size());
    }
    @Test void allowsSharedContactAndFindsByMultipleFields() {
        var p = service.themKhachHang(data("Nguyễn Văn A", null, null, null));
        service.themKhachHang(data("Trần Văn B", null, null, null));
        assertEquals(2, service.timKhachHang(new BoLocKhachHang("0912", null, null, null)).size());
        assertEquals(1, service.timKhachHang(new BoLocKhachHang(p.maKhachHang(), null, null, null)).size());
        assertFalse(service.canhBaoTrung(null, data("C", null, null, null)).isEmpty());
    }
    @Test void rejectsMissingNameIncompleteDocumentsAndBadDates() {
        assertThrows(IllegalArgumentException.class, () -> service.themKhachHang(data(" ", null, null, null)));
        assertThrows(IllegalArgumentException.class, () -> service.themKhachHang(data("A", LoaiGiayTo.CCCD, null, "VN")));
        assertThrows(IllegalArgumentException.class, () -> service.themKhachHang(data("A", LoaiGiayTo.CCCD, "123", "VN")));
        var future = new DuLieuKhachHang("A", null, null, null, null, null,
                LocalDate.now(ZoneId.of("Asia/Ho_Chi_Minh")).plusDays(1), GioiTinh.KHAC, null, null);
        assertThrows(IllegalArgumentException.class, () -> service.themKhachHang(future));
    }
    @Test void concurrentDuplicateInsertStoresOnlyOneProfile() throws Exception {
        var executor = Executors.newFixedThreadPool(2);
        try {
            var d = data("A", LoaiGiayTo.CCCD, "012345678901", "VN");
            Callable<Boolean> task = () -> {
                try { service.themKhachHang(d); return true; }
                catch (IllegalArgumentException e) { return false; }
            };
            var results = executor.invokeAll(java.util.List.of(task, task));
            int successes = 0;
            for (var result : results) if (result.get()) successes++;
            assertEquals(1, successes);
        } finally { executor.shutdownNow(); }
    }
    @Test void rejectsInvalidPhoneEmailAndCountry() {
        assertThrows(IllegalArgumentException.class, () -> service.themKhachHang(new DuLieuKhachHang(
                "A", null, null, null, "123", null, null, null, null, null)));
        assertThrows(IllegalArgumentException.class, () -> service.themKhachHang(new DuLieuKhachHang(
                "A", null, null, null, null, "invalid", null, null, null, null)));
        assertThrows(IllegalArgumentException.class, () -> service.themKhachHang(new DuLieuKhachHang(
                "A", null, null, null, null, null, null, null, "XX", null)));
    }
    @Test void normalisesInternationalContactAndFiltersStatusGenderCountry() {
        var p = service.themKhachHang(new DuLieuKhachHang("Foreign guest", LoaiGiayTo.PASSPORT,
                "ab123", "us", "+1 (202) 555-0123", null, null, GioiTinh.KHAC, "us", null));
        assertEquals("+12025550123", p.soDienThoai());
        assertEquals("AB123", p.soGiayTo());
        assertEquals(1, service.timKhachHang(new BoLocKhachHang("foreign", GioiTinh.KHAC, "US", TrangThaiKhachHang.HOAT_DONG)).size());
        assertEquals(0, service.timKhachHang(new BoLocKhachHang(null, GioiTinh.NAM, null, null)).size());
        service.voHieuHoa(p.maKhachHang());
        assertEquals(0, service.timKhachHang(new BoLocKhachHang(null, null, "US", TrangThaiKhachHang.HOAT_DONG)).size());
    }
    @Test void keepsVietnameseTextAndRejectsOverlongInput() {
        var p = service.themKhachHang(data("Đặng Thị Ánh", null, null, null));
        assertEquals(1, service.timKhachHang(new BoLocKhachHang("đặng", null, null, null)).size());
        assertThrows(IllegalArgumentException.class, () -> service.themKhachHang(data("a".repeat(101), null, null, null)));
        assertThrows(IllegalArgumentException.class, () -> service.suaKhachHang("MISSING", data("A", null, null, null)));
        assertEquals("Đặng Thị Ánh", p.hoTen());
    }
}
