# Module Quản lý Khách hàng — HotelManagement

Java 17 trở lên, Swing, Maven, SQL Server/JDBC, MVC. Mở thư mục này bằng NetBeans (File → Open Project), chọn demo.ModuleKhachHangApp làm Main Class nếu được hỏi.

## Chạy ngay trong NetBeans

1. Dừng cửa sổ demo cũ nếu đang chạy.
2. Nhấp phải project → Clean and Build.
3. Run Project (nút tam giác xanh).
4. Chọn một dòng để bật Sửa, Xem chi tiết và Vô hiệu hóa/Kích hoạt lại.

Không cần SQL Server để chạy demo. Bốn hồ sơ mẫu được tạo mỗi lần chạy; thay đổi ở chế độ DEMO chỉ giữ trong bộ nhớ và mất khi đóng ứng dụng. Banner trên giao diện hiển thị rõ chế độ này.

## Các chức năng đã triển khai

- Thêm/sửa hồ sơ, xem chi tiết, danh sách và tải lại.
- Tìm theo mã, họ tên, CCCD/Passport hoặc điện thoại; kết hợp lọc giới tính, quốc tịch và trạng thái.
- Sắp xếp bằng cách bấm tiêu đề cột; Enter hoặc nhấp đúp để xem chi tiết.
- Vô hiệu hóa/kích hoạt lại; luôn giữ mã, ngày tạo và hồ sơ cũ.
- Validation ở Service; thông báo lỗi ở form, dữ liệu nhập được giữ khi lưu thất bại.
- Chống trùng loại giấy tờ + nước cấp + số giấy tờ, kể cả hồ sơ vô hiệu hóa.
- Cảnh báo trùng điện thoại hoặc cùng họ tên/ngày sinh, vẫn cho lưu nếu người dùng đã kiểm tra.
- Thực hiện thao tác nền bằng SwingWorker, cập nhật giao diện trên EDT.
- Hai DAO: MemoryKhachHangDAO cho demo; SqlServerKhachHangDAO cho lưu dữ liệu thật.

Họ tên bắt buộc. Chưa có giấy tờ thì để trống cả loại/số/nước cấp. CCCD gồm 12 chữ số, nước cấp VN. Passport nhận chữ/số; số giấy tờ và điện thoại dùng String. Quốc tịch và nước cấp dùng mã quốc gia 2 chữ như VN, US, GB. Ngày sinh nhập dd/MM/yyyy. Đây là kiểm tra định dạng, không xác minh giấy tờ thật.

## Kết nối SQL Server sau này

1. Có SQL Server đang chạy và database chung của nhóm đã được tạo.
2. Chọn đúng database rồi chạy sql/04_module_khachhang.sql. Script không tạo database hoặc sửa bảng module khác; từ chối nếu bảng KhachHang đã tồn tại.
3. Nếu muốn dữ liệu mẫu, chạy sql/05_du_lieu_mau_khachhang.sql trên database thử nghiệm.
4. Sao chép config/db.properties.example thành config/db.properties.
5. Đổi mode=sqlserver; điền db.url, tên database và db.user. Điền db.password trong file riêng hoặc dùng biến môi trường HOTEL_DB_PASSWORD. Các khóa url/user/password cũ vẫn được hỗ trợ nếu thiếu khóa db.*.
6. Run Project. Banner phải hiển thị SQL Server. Thêm một khách, đóng/mở ứng dụng rồi kiểm tra khách vẫn còn.

Mặc định JDBC kiểm tra chứng chỉ TLS. Máy thử nghiệm dùng chứng chỉ tự ký có thể cần trustServerCertificate=true; cấu hình này bỏ kiểm tra chứng chỉ server. Tham khảo [tài liệu Microsoft](https://learn.microsoft.com/en-us/sql/connect/jdbc/connecting-with-ssl-encryption).

Không đưa config/db.properties hoặc mật khẩu vào Git. Khi chọn sqlserver mà kết nối lỗi, ứng dụng báo lỗi, không tự chuyển sang demo.

## Cấu trúc và phần OOP/MVC

- model/: KhachHang record bất biến; DuLieuKhachHang cho thêm/sửa; BoLocKhachHang và enum.
- dao/: KhachHangDAO là interface; SQL Server và Memory là hai implementation thể hiện đa hình.
- service/: validation, chuẩn hóa, trạng thái, cảnh báo trùng và API tích hợp.
- controller/: điều phối thao tác và SwingWorker.
- view/: KhachHangPanel, form thêm/sửa và dialog chi tiết; không viết SQL hoặc gọi DAO.
- common/: ConnectionFactory và DBConnection cho kết nối cấu hình ngoài source.
- demo/: JFrame chạy thử; nhóm nhúng JPanel vào MainFrame thật.
- src/test/java/: kiểm thử Service và luồng tải panel.
- sql/: script schema và dữ liệu mẫu.

Record đọc bằng khachHang.hoTen(), không có setter. Service/DAO tạo đối tượng mới khi sửa; mã/ngày tạo không đổi. Enum name() dùng cho DB, nhan() dùng cho giao diện.

## Kiểm tra và chạy ngoài NetBeans

```sh
mvn clean test
mvn package
mvn exec:java
```

Chạy Test Project trong NetBeans để chạy JUnit. Kiểm thử bao gồm chuẩn hóa, trùng giấy tờ, giấy tờ nước ngoài, điện thoại/email, ngày sinh, trạng thái, cảnh báo trùng, tìm/lọc, thêm đồng thời và tải bảng ngoài EDT. Kiểm thử Memory không thay thế kiểm thử SQL Server thật.

Thử bằng giao diện: thêm khách → sửa → xem chi tiết → tìm theo mã/điện thoại → vô hiệu hóa → lọc ngừng hoạt động → kích hoạt lại → tải lại. Thử họ tên rỗng, ngày 31/02/2000, email sai và thêm cùng CCCD; ứng dụng phải báo lỗi và giữ form.

## Tích hợp và giới hạn hiện tại

Xem docs/BAN_GIAO_KHACH_HANG.md để ghép MainFrame và Đặt phòng. Chưa có module Đặt phòng/Dịch vụ/Tài chính trong project này nên chưa hiển thị lịch sử booking, lưu trú, dịch vụ hoặc hóa đơn. Điểm/hạng thành viên, đánh giá và thống kê là các phần mở rộng sau chức năng cốt lõi.

Tìm kiếm hiện tải snapshot rồi lọc ở Service, phù hợp quy mô bài tập; chưa có phân trang cho dữ liệu lớn. Chưa xác minh DAO/script trên SQL Server thật vì người dùng chưa có server.
