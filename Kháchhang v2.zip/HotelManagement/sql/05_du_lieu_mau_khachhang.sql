-- Tùy chọn: chỉ chạy trên database thử nghiệm, sau script 04.
-- Dữ liệu hư cấu. Service dùng giờ Asia/Ho_Chi_Minh; script lấy giờ UTC + 7.
SET XACT_ABORT ON;
BEGIN TRANSACTION;
IF NOT EXISTS (SELECT 1 FROM dbo.KhachHang WHERE SoGiayTo='012345678901' AND QuocGiaCap='VN')
BEGIN
    DECLARE @n BIGINT = NEXT VALUE FOR dbo.SeqKhachHang;
    INSERT INTO dbo.KhachHang(MaKhachHang,HoTen,LoaiGiayTo,SoGiayTo,QuocGiaCap,
        SoDienThoai,Email,NgaySinh,GioiTinh,QuocTich,DiaChi,NgayTao,TrangThai)
    VALUES('KH'+FORMAT(@n,'00000000'),N'Nguyễn Minh Anh','CCCD','012345678901','VN',
        '0901234567',N'anh@example.com','20000520','NU','VN',N'Hà Nội',
        DATEADD(HOUR,7,SYSUTCDATETIME()),'HOAT_DONG');
END;
IF NOT EXISTS (SELECT 1 FROM dbo.KhachHang WHERE SoGiayTo='DEMO12345' AND QuocGiaCap='US')
BEGIN
    DECLARE @n2 BIGINT = NEXT VALUE FOR dbo.SeqKhachHang;
    INSERT INTO dbo.KhachHang(MaKhachHang,HoTen,LoaiGiayTo,SoGiayTo,QuocGiaCap,
        SoDienThoai,Email,GioiTinh,QuocTich,NgayTao,TrangThai)
    VALUES('KH'+FORMAT(@n2,'00000000'),N'Alex Morgan','PASSPORT','DEMO12345','US',
        '+12025550123',N'alex@example.com','KHONG_CUNG_CAP','US',
        DATEADD(HOUR,7,SYSUTCDATETIME()),'HOAT_DONG');
END;
COMMIT TRANSACTION;
