-- Chạy trong database chung đã chọn. Không tạo DB mới, không sửa bảng module khác.
SET XACT_ABORT ON;
BEGIN TRANSACTION;
IF OBJECT_ID(N'dbo.KhachHang', N'U') IS NOT NULL
    THROW 50001, N'Bảng KhachHang đã tồn tại. Đối chiếu schema, không chạy lại script tạo.', 1;

CREATE SEQUENCE dbo.SeqKhachHang AS BIGINT START WITH 1 INCREMENT BY 1
    MINVALUE 1 MAXVALUE 999999999999999999 NO CYCLE;

CREATE TABLE dbo.KhachHang (
    MaKhachHang VARCHAR(20) NOT NULL CONSTRAINT PK_KhachHang PRIMARY KEY,
    HoTen NVARCHAR(100) NOT NULL,
    LoaiGiayTo VARCHAR(10) NULL,
    SoGiayTo VARCHAR(30) NULL,
    QuocGiaCap CHAR(2) NULL,
    SoDienThoai VARCHAR(20) NULL,
    Email NVARCHAR(254) NULL,
    NgaySinh DATE NULL,
    GioiTinh VARCHAR(15) NOT NULL CONSTRAINT DF_KhachHang_GioiTinh DEFAULT 'KHONG_CUNG_CAP',
    QuocTich CHAR(2) NULL,
    DiaChi NVARCHAR(255) NULL,
    NgayTao DATETIME2(0) NOT NULL,
    TrangThai VARCHAR(20) NOT NULL CONSTRAINT DF_KhachHang_TrangThai DEFAULT 'HOAT_DONG',
    CONSTRAINT CK_KhachHang_HoTen CHECK (LEN(LTRIM(RTRIM(HoTen))) > 0),
    CONSTRAINT CK_KhachHang_GioiTinh CHECK (GioiTinh IN ('NAM','NU','KHAC','KHONG_CUNG_CAP')),
    CONSTRAINT CK_KhachHang_TrangThai CHECK (TrangThai IN ('HOAT_DONG','NGUNG_HOAT_DONG')),
    CONSTRAINT CK_KhachHang_GiayTo CHECK (
        (LoaiGiayTo IS NULL AND SoGiayTo IS NULL AND QuocGiaCap IS NULL)
        OR (LoaiGiayTo IS NOT NULL AND SoGiayTo IS NOT NULL AND QuocGiaCap IS NOT NULL
            AND LoaiGiayTo IN ('CCCD','PASSPORT') AND LEN(SoGiayTo) > 0 AND LEN(QuocGiaCap)=2)),
    CONSTRAINT CK_KhachHang_CCCD CHECK (LoaiGiayTo IS NULL OR LoaiGiayTo <> 'CCCD'
        OR (QuocGiaCap='VN' AND LEN(SoGiayTo)=12 AND SoGiayTo NOT LIKE '%[^0-9]%'))
);
CREATE UNIQUE INDEX UX_KhachHang_GiayTo
    ON dbo.KhachHang(LoaiGiayTo, QuocGiaCap, SoGiayTo) WHERE SoGiayTo IS NOT NULL;
CREATE INDEX IX_KhachHang_SoDienThoai ON dbo.KhachHang(SoDienThoai);
COMMIT TRANSACTION;
