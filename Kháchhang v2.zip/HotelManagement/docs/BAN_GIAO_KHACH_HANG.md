# Bàn giao module Khách hàng

## Đối chiếu tên gọi với module Phòng

- DBConnection dùng db.url/db.user/db.password; vẫn đọc url/user/password cũ khi không có khóa mới. HOTEL_DB_PASSWORD có ưu tiên cao nhất.
- KhachHang.sdt() tương đương soDienThoai(). KhachHang.cccd() chỉ trả số CCCD; Passport hoặc thiếu giấy tờ trả null.
- KhachHangService.getKhachHangs() trả khách đang hoạt động cho bộ chọn. Cần mọi trạng thái thì dùng timKhachHang(new BoLocKhachHang(null, null, null, null)).
- Model đầy đủ 13 trường và các cột giấy tờ vẫn được giữ để không mất hỗ trợ khách nước ngoài.
- Chưa có khai báo record 6 trường và chữ ký luuKhachHang(...) của module Phòng trong source được cung cấp, nên chưa xác nhận tương thích constructor/phương thức lưu. Không tạo overload đoán thứ tự tham số.
- Mã là String/VARCHAR(20): KH001 và KH00000001 đều là giá trị chuỗi hợp lệ trong schema. Hiện Service tạo mã tự động; chưa hỗ trợ thêm bằng mã nhập tay. Module gọi nên lấy mã từ hồ sơ trả về và không tự sinh một mã khác.

## MainFrame

Java 17 trở lên, package module_khachhang; panel chính là KhachHangPanel. Dùng một service chung cho panel và Đặt phòng.

```java
DBConnection db = new DBConnection(Path.of("config/db.properties"));
KhachHangService khachHangService = new KhachHangService(new SqlServerKhachHangDAO(db));
// Tạo Swing component trên EDT; cấu hình theme một lần trong MainFrame chung.
KhachHangPanel panel = new KhachHangPanel(
        new KhachHangController(khachHangService), "SQL Server");
pnlNoiDung.add(panel, "KHACH_HANG");
((CardLayout) pnlNoiDung.getLayout()).show(pnlNoiDung, "KHACH_HANG");
```

Import common.DBConnection, java.nio.file.Path, java.awt.CardLayout và các class module tương ứng. pnlNoiDung là JPanel CardLayout của nhóm, không được tạo bởi module. Không gọi demo.ModuleKhachHangApp khi ghép MainFrame. Một controller chỉ gắn một panel. panel.taiLai() làm mới dữ liệu; gọi trên EDT.

common hiện là bản kết nối khởi đầu, cần đối chiếu API source common của module Phòng khi nhóm ghép. DAO nhận ConnectionFactory nên có thể dùng adapter `new SqlServerKhachHangDAO(db::open)` nếu phần chung có phương thức open tương đương.

## API KhachHangService

| Phương thức | Ý nghĩa |
|---|---|
| themKhachHang(DuLieuKhachHang) | Trả hồ sơ mới, mã/ngày tạo được tự sinh |
| suaKhachHang(String ma, DuLieuKhachHang) | Chỉ sửa thông tin, không thay mã/ngày tạo/trạng thái |
| getKhachHang(String ma) | Đọc cả hồ sơ vô hiệu hóa, lỗi khi không tồn tại |
| timKhachHang(BoLocKhachHang) | Từ khóa và bộ lọc; null trong bộ lọc nghĩa là tất cả |
| getKhachHangHoatDong() | Danh sách cho bộ chọn booking mới |
| voHieuHoa(String), kichHoatLai(String) | Đổi trạng thái, không xóa hồ sơ |
| canhBaoTrung(String ma, DuLieuKhachHang) | Hồ sơ có liên hệ hoặc họ tên/ngày sinh tương tự; ma=null khi thêm |
| getKhachHangChoDatPhong(Connection c, String ma) | Khóa/kiểm tra khách hoạt động trong transaction SQL của caller |

Service synchronous; module gọi phải dùng worker nếu thao tác từ Swing. Lỗi validation là IllegalArgumentException; lỗi SQL là IllegalStateException có cause SQLException. API nhận Connection khai báo SQLException; caller phải rollback cả lỗi SQL lẫn RuntimeException.

## Liên kết Đặt phòng

DatPhong.MaKhachHang VARCHAR(20) FK → dbo.KhachHang.MaKhachHang; không cascade delete. DatPhong do thành viên Đặt phòng tạo. Trạng thái khách: HOAT_DONG hoặc NGUNG_HOAT_DONG. Không tạo khách riêng trong booking hoặc sửa bảng KhachHang trực tiếp.

```java
try (Connection c = db.open()) {
    c.setAutoCommit(false);
    try {
        KhachHang khach = khachHangService.getKhachHangChoDatPhong(c, maKhachHang);
        // phongService.giuPhong(c, maPhong);
        // datPhongDAO.them(c, booking); // DAO booking phải dùng chính c.
        c.commit();
    } catch (SQLException | RuntimeException e) {
        try { c.rollback(); } catch (SQLException rollback) { e.addSuppressed(rollback); }
        throw e;
    }
}
```

Import java.sql.Connection/SQLException và module_khachhang.model.KhachHang. API không tự đóng Connection/commit/rollback. UPDATE trạng thái khách phải chờ khóa của booking để tránh khách bị vô hiệu hóa giữa kiểm tra và tạo booking. Thống nhất thứ tự khóa khách rồi phòng trong tất cả luồng cần cả hai. Không mở kết nối thứ hai để đọc cùng khách sau khi caller đã khóa dòng.

Cho phép hồ sơ chưa có giấy tờ để đặt trước. Điều kiện đủ giấy tờ để check-in phải do nhóm thống nhất; chưa được tự áp vào mọi hồ sơ. Phiên bản đầu đề xuất một khách đại diện mỗi booking; danh sách người thực tế ở thuộc phần Đặt phòng/Lưu trú nếu cần mở rộng.

## Các module khác

- Phòng: không phụ thuộc trực tiếp vào model Phong; lịch sử phòng của khách lấy qua lần đặt/lưu trú.
- Dịch vụ: liên kết phát sinh với MaDatPhong/MaLuuTru, không chỉ MaKhachHang.
- Tài chính: lấy khách qua booking; nếu cần thông tin chứng từ không đổi, Tài chính lưu snapshot phù hợp. Không tự thêm MaKhachHang vào HoaDon khi chưa chốt người đặt/người trả tiền.
- Lịch sử: service Đặt phòng/Dịch vụ/Tài chính cung cấp dữ liệu khi các module đó có source. KhachHangDAO hiện chỉ sở hữu bảng KhachHang.

Database đề xuất HotelManagementDB vẫn cần nhóm chốt. LoaiGiayTo + QuocGiaCap + SoGiayTo là bộ khóa duy nhất có điều kiện khi có giấy tờ. Điện thoại/email không UNIQUE. Sequence tăng dần, có thể khuyết số sau rollback; không tái sử dụng mã. [Microsoft mô tả sequence](https://learn.microsoft.com/en-us/sql/relational-databases/sequence-numbers?view=sql-server-ver17) và [unique index](https://learn.microsoft.com/en-us/sql/relational-databases/indexes/create-unique-indexes?view=sql-server-2017).
