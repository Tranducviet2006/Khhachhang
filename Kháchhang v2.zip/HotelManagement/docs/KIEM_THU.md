# Kiểm thử module Khách hàng

Lượt tương thích module Phòng: tổng cộng 16 test đạt, không lỗi/bỏ qua. Bổ sung 2 test JDBC configuration (khóa db.* được ưu tiên, khóa cũ vẫn đọc) và 3 test sdt()/cccd()/getKhachHangs(). Kiểm thử cấu hình dùng driver giả không kết nối mạng; không thay thế thử SQL Server thật.

Đã biên dịch với release 17 trên JDK 25, đóng gói Maven thành công.

Sau lượt đơn giản hóa code: giữ nguyên bộ test, 11 test vẫn đạt. Lượt sửa tách tạo giao diện/gắn sự kiện, đổi tên trường Swing, gom xử lý lỗi lưu và thông báo số lượng, làm rõ điều kiện tìm kiếm/cảnh báo trùng; không đổi API tích hợp hoặc schema SQL.

## Kiểm thử tự động

`mvn clean test`: 11 test, không lỗi, không bỏ qua.

- 10 test nghiệp vụ: thêm/chuẩn hóa, giấy tờ trùng kể cả khách vô hiệu hóa, Passport khác nước cấp, sửa giữ mã/ngày tạo/trạng thái, liên hệ dùng chung và cảnh báo, tìm/lọc, ngày sinh và giấy tờ thiếu, thêm đồng thời, định dạng liên hệ/quốc gia, tiếng Việt và độ dài.
- 1 test Swing: tải DAO trên worker, bảng không sửa trực tiếp, nút thao tác theo lựa chọn, giữ lựa chọn khi tải lại/sắp xếp và trạng thái bảng rỗng.

## Kiểm thử cửa sổ thật

SwingWorkflowSmoke là chương trình chạy riêng, không chạy tự động trong Test Project vì cần màn hình. Chỉ thao tác trên cửa sổ nó tạo và Memory DAO của chính nó.

Sau `mvn test-compile`, trên macOS/Linux:

```sh
java -cp target/classes:target/test-classes module_khachhang.SwingWorkflowSmoke target/ui-preview.png
```

Windows thay dấu `:` giữa hai đường dẫn bằng `;`.

Đã chạy đạt các bước ADD_OK, EDIT_OK, DETAIL_OK, DEACTIVATE_OK, REACTIVATE_OK, SEARCH_RESET_OK, UI_OK; bản cuối không còn cảnh báo sorter. Chương trình đóng cửa sổ kiểm thử và xuất ảnh panel. Thất bại trả mã thoát khác 0.

## Phần cần SQL Server thật

Người dùng xác nhận chưa có SQL Server. Vì vậy chưa chạy script/schema, JDBC CRUD, UNIQUE constraint hoặc khóa transaction với booking trên server thật. Khi có server cần kiểm tra:

1. Script 04 tạo bảng/index/sequence, script 05 thêm dữ liệu mẫu.
2. JDBC lưu và đọc lại hồ sơ tiếng Việt, các trường NULL và thời gian.
3. Hai kết nối thêm cùng giấy tờ chỉ một kết nối thành công.
4. Sửa/vô hiệu hóa giữ mã/ngày tạo; đóng/mở ứng dụng giữ dữ liệu.
5. Transaction booking khóa khách; thay đổi trạng thái ở kết nối khác phải chờ commit/rollback.
6. Không có cascade delete làm mất lịch sử.

Không dùng kết quả Memory/GUI để kết luận các bước SQL Server này đã đạt.
